.. _`usShell3(1)`:

usShell3
========

.. warning::

   The :program:`usShell3` is experimental and is subject to change
   in between minor releases.

Command-Line Reference
----------------------

The following options are supported by the :program:`usShell3` program:

.. program:: usShell3

.. option:: --help, -h

   Print usage and exit.

.. option:: --load, -l

   Load bundle.
