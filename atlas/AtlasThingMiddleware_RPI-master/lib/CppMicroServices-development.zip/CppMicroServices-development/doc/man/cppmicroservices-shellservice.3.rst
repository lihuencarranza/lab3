Shell Service API
=================

These classes are the main API to the Shell Service bundle

.. warning::

   The Shell Service API is not final and may be incomplete.
   It also may change between minor releases without backwards
   compatibility guarantees.

.. toctree::
   :glob:
   
   /shellservice/doc/api/*