ShellService
------------

.. doxygenclass:: cppmicroservices::ShellService
